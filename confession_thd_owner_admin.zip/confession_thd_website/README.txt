CONFESSION TRƯỜNG THPT TRẦN HƯNG ĐẠO — WEBSITE VÀ QUẢN TRỊ

CÁCH MỞ
1. Giải nén toàn bộ thư mục.
2. Mở index.html bằng Edge hoặc Chrome.
3. Nhấn “Nội quy” để đọc nội quy; biểu mẫu yêu cầu xác nhận đã đọc nội quy trước khi gửi.
4. Nhấn “Đăng nhập Admin” để quản lý bài viết và giao diện.

ĐĂNG NHẬP QUẢN TRỊ MẶC ĐỊNH
- Owner tổng lần đầu: owner
- Mật khẩu Owner lần đầu: Owner-THD-2026!
- Đăng nhập Admin > mục “Quản lý Admin” để tạo tài khoản cho người duyệt bài.
Hãy đổi mật khẩu Owner ngay sau khi đăng nhập.

CHỨC NĂNG
- Gửi confession và xác nhận nội quy bắt buộc.
- Trang nội quy riêng.
- Owner tổng có thể tạo/khóa/xóa tài khoản Admin.
- Admin được duyệt, chỉnh sửa, từ chối, đánh dấu đã đăng và truy cập kho lưu trữ confession.
- Owner có toàn quyền, gồm chỉnh giao diện và xóa bài vĩnh viễn.
- Sao chép nội dung để quản trị viên đăng thủ công lên Fanpage.
- Chỉnh tiêu đề, lời giới thiệu, câu hỏi, ảnh banner và giao diện sáng/tối.

GIỚI HẠN HIỆN TẠI — ĐỌC KỸ
Đây là phiên bản chạy cục bộ bằng HTML/CSS/JavaScript. Bài viết, tài khoản và quyền được lưu trong localStorage của trình duyệt trên thiết bị đang mở trang. Việc phân quyền chỉ phục vụ thử nghiệm; người biết kỹ thuật có thể sửa dữ liệu trình duyệt, và dữ liệu không đồng bộ sang thiết bị khác. Không dùng để nhận confession công khai thật cho đến khi tích hợp máy chủ, cơ sở dữ liệu và xác thực quản trị an toàn (ví dụ Supabase Auth + Row Level Security).

Website không tự đăng bài lên Facebook. Quản trị viên cần sao chép và đăng thủ công.
